// Requires: npm install sharp --save-dev
// Usage: node scripts/generate-icons.js public/assets/logo.png
import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

async function generate(src) {
  if (!src || !fs.existsSync(src)) {
    console.error('Usage: node scripts/generate-icons.js path/to/source-logo.png');
    process.exit(1);
  }

  const outDir = path.resolve('public/assets');
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

  const sizes = [
    { name: 'logo-192.png', size: 192 },
    { name: 'logo-512.png', size: 512 },
    { name: 'logo-maskable.png', size: 512 }
  ];

  console.log('🚀 Generating icons from:', src);

  await Promise.all(sizes.map(s =>
    sharp(src)
      .resize(s.size, s.size, { fit: 'contain', background: { r: 5, g: 5, b: 5, alpha: 1 } })
      .png()
      .toFile(path.join(outDir, s.name))
  ));

  console.log('✅ Icons generated to public/assets/');
}

const src = process.argv[2];
generate(src).catch(err => { console.error('❌ Generation failed:', err); process.exit(1); });