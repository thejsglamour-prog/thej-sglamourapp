
import React, { useState, useEffect, useRef } from 'react';
import { API, BookingRecord, AnalyticsSummary, SystemLog, SystemMetrics } from '../services/api';
import { SERVICES } from '../constants';

const ConciergeDashboard: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'queue' | 'analytics' | 'console'>('queue');
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const logEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadInitialData();
    const interval = setInterval(refreshState, 3000); 
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (activeTab === 'console' && logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, activeTab]);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [b, a, l, m] = await Promise.all([
        API.getBookings(),
        API.getAnalytics(),
        API.getLogs(),
        API.getSystemMetrics()
      ]);
      setBookings(b);
      setAnalytics(a);
      setLogs(l);
      setMetrics(m);
    } finally {
      setLoading(false);
    }
  };

  const refreshState = async () => {
    const [l, m, a, b] = await Promise.all([
      API.getLogs(), 
      API.getSystemMetrics(), 
      API.getAnalytics(),
      API.getBookings()
    ]);
    setLogs(l);
    setMetrics(m);
    setAnalytics(a);
    setBookings(b);
  };

  const updateStatus = async (id: string, status: BookingRecord['status']) => {
    await API.updateBookingStatus(id, status);
    loadInitialData();
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#050505]/98 flex flex-col animate-in fade-in duration-700 backdrop-blur-3xl overflow-hidden">
      {/* Header */}
      <div className="px-6 lg:px-12 py-6 border-b border-white/5 flex justify-between items-center bg-stone-900/20 backdrop-blur-md">
        <div className="flex items-center gap-4 lg:gap-6">
          <div className="w-10 h-10 lg:w-14 lg:h-14 bg-[#D4AF37] rounded-xl p-2 shadow-2xl transition-transform hover:scale-110">
             <img src="https://img.icons8.com/color/512/scissors.png" alt="Logo" className="w-full h-full brightness-0 invert" />
          </div>
          <div>
            <h2 className="text-xl lg:text-3xl font-black text-white tracking-widest font-serif italic uppercase leading-none">
              Master <span className="text-[#D4AF37]">OS</span>
            </h2>
            <p className="text-stone-600 text-[8px] lg:text-[10px] font-black uppercase tracking-[0.6em] mt-1 lg:mt-2">Abuloma_Node_V10.2 // Online</p>
          </div>
        </div>

        <nav className="hidden md:flex bg-black/50 p-1.5 rounded-2xl border border-white/5 shadow-inner">
          {(['queue', 'analytics', 'console'] as const).map((tab) => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-10 py-3 rounded-xl text-[10px] lg:text-[11px] font-black uppercase tracking-widest transition-all duration-500 ${
                activeTab === tab ? 'bg-[#D4AF37] text-black shadow-lg scale-105' : 'text-stone-500 hover:text-white'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>

        <button onClick={onClose} className="p-4 bg-white/5 rounded-2xl text-white hover:bg-red-500/80 transition-all border border-white/10 group">
          <svg className="w-6 h-6 transition-transform group-hover:rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6" />
          </svg>
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-grow overflow-y-auto p-6 lg:p-12 scrollbar-hide">
        <div className="max-w-[1400px] mx-auto h-full space-y-12">
          {loading ? (
             <div className="flex flex-col items-center justify-center h-full gap-6">
                <div className="w-16 h-16 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin shadow-[0_0_40px_rgba(212,175,55,0.3)]"></div>
                <span className="text-stone-600 text-[10px] font-black uppercase tracking-widest animate-pulse">Establishing Secure Node Link...</span>
             </div>
          ) : activeTab === 'queue' ? (
            <div className="space-y-8 pb-32">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                 {[
                   { label: 'System Uptime', val: metrics?.uptime, color: 'text-white' },
                   { label: 'Node Latency', val: `${metrics?.latency}ms`, color: 'text-green-500' },
                   { label: 'Thread Load', val: `${metrics?.load.toFixed(1)}%`, color: 'text-[#D4AF37]' },
                   { label: 'Projected Revenue', val: `₦${analytics?.estimatedRevenue.toLocaleString()}`, color: 'text-white' }
                 ].map((s, i) => (
                   <div key={i} className="p-8 bg-stone-900/40 border border-white/5 rounded-3xl backdrop-blur-3xl shadow-2xl group hover:border-[#D4AF37]/30 transition-all">
                      <p className="text-stone-700 text-[9px] font-black uppercase tracking-[0.3em] mb-4">{s.label}</p>
                      <p className={`text-2xl lg:text-4xl font-black ${s.color} tracking-tighter font-serif drop-shadow-sm`}>{s.val}</p>
                   </div>
                 ))}
              </div>

              <div className="space-y-6">
                <div className="flex items-center gap-4 mb-2">
                   <h3 className="text-white text-sm font-black uppercase tracking-[0.5em]">Live_Registry_Queue</h3>
                   <div className="flex-grow h-px bg-white/5"></div>
                </div>
                {bookings.length === 0 ? (
                  <div className="py-32 text-center border border-dashed border-white/10 rounded-3xl bg-stone-900/10">
                    <p className="text-stone-700 text-xs font-black uppercase tracking-[0.8em]">Registry Ledger Clear</p>
                  </div>
                ) : (
                  bookings.map((b) => (
                    <div key={b.id} className="p-8 bg-[#0a0a0a] border border-white/5 rounded-3xl flex flex-col lg:flex-row gap-8 lg:items-center hover:bg-stone-900/30 transition-all group animate-in slide-in-from-left duration-700 shadow-xl">
                       <div className="flex-grow">
                          <div className="flex flex-wrap items-center gap-6 mb-6">
                             <span className="text-2xl md:text-3xl font-serif text-white italic tracking-tighter leading-none">{b.name}</span>
                             <span className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest ${
                               b.status === 'Pending' ? 'bg-[#D4AF37] text-black' : 
                               b.status === 'Confirmed' ? 'bg-blue-500 text-white' : 
                               b.status === 'Cancelled' ? 'bg-red-900 text-white opacity-50' : 'bg-green-600 text-white'
                             }`}>{b.status}</span>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-[10px] font-mono text-stone-500 uppercase tracking-widest">
                             <div className="flex flex-col gap-1">
                                <span className="text-stone-700 text-[8px]">Protocol_ID</span>
                                <span className="text-white/60">{b.id}</span>
                             </div>
                             <div className="flex flex-col gap-1">
                                <span className="text-stone-700 text-[8px]">Assigned_Artisan</span>
                                <span className="text-[#D4AF37]">{b.stylist}</span>
                             </div>
                             <div className="flex flex-col gap-1">
                                <span className="text-stone-700 text-[8px]">Sync_Time</span>
                                <span className="text-white/60">{b.date} // {b.time}</span>
                             </div>
                             <div className="flex flex-col gap-1">
                                <span className="text-stone-700 text-[8px]">Request_Type</span>
                                <span className="text-white/60">{b.service}</span>
                             </div>
                          </div>
                       </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : activeTab === 'console' ? (
            <div className="bg-black border border-white/5 font-mono h-[600px] lg:h-[800px] flex flex-col rounded-3xl overflow-hidden shadow-[0_100px_200px_rgba(0,0,0,1)] relative">
               <div className="px-8 py-6 border-b border-white/10 bg-stone-900/40 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 bg-[#D4AF37] rounded-full animate-pulse shadow-[0_0_15px_#D4AF37]"></div>
                    <span className="text-[10px] font-black text-stone-400 uppercase tracking-[0.4em]">Live_Protocol_Telemetry</span>
                  </div>
                  <span className="text-[8px] text-stone-600 uppercase tracking-widest">Deploy_Ready</span>
               </div>
               <div className="flex-grow overflow-y-auto p-8 space-y-4 scroll-smooth no-scrollbar">
                  {logs.map((log) => (
                    <div key={log.id} className="flex gap-6 text-[11px] lg:text-sm animate-in fade-in slide-in-from-left-4 duration-500">
                       <span className="text-stone-800 shrink-0 font-mono">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                       <span className={`font-black shrink-0 tracking-widest ${
                         log.type === 'ai' ? 'text-[#D4AF37]' : 
                         log.type === 'success' ? 'text-green-500' : 
                         log.type === 'system' ? 'text-blue-500' : 'text-stone-600'
                       }`}>
                         {log.type.toUpperCase()}
                       </span>
                       <span className="text-stone-400 font-light leading-relaxed">{log.message}</span>
                    </div>
                  ))}
                  <div ref={logEndRef}></div>
               </div>
            </div>
          ) : (
             <div className="py-20 text-center text-stone-500 uppercase tracking-[1em] font-black text-[10px]">
               Analytics_Engine_Synchronized
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ConciergeDashboard;
