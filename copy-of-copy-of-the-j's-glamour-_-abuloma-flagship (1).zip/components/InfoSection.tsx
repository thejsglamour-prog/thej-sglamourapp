
import React, { useState, useEffect } from 'react';
import { BUSINESS_INFO } from '../constants';

const InfoSection: React.FC = () => {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [distance, setDistance] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Salon coordinates (approximate for Abuloma, PH)
  const SALON_COORDS = { lat: 4.777065, lng: 7.050388 };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return (R * c).toFixed(2);
  };

  const syncLocation = () => {
    setIsSyncing(true);
    setLocationError(null);

    if (!navigator.geolocation) {
      setLocationError("Geolocation protocols not supported by hardware.");
      setIsSyncing(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        const dist = calculateDistance(latitude, longitude, SALON_COORDS.lat, SALON_COORDS.lng);
        setDistance(dist);
        setIsSyncing(false);
      },
      (error) => {
        setLocationError("Sync failed: " + error.message);
        setIsSyncing(false);
      },
      { enableHighAccuracy: true }
    );
  };

  return (
    <section id="location" className="py-24 lg:py-40 bg-[#050505] border-y border-white/5 relative">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          
          <div className="z-10 order-2 lg:order-1">
            <span className="text-[#D4AF37] font-bold text-[8px] lg:text-[10px] uppercase tracking-[1em] block mb-8">Spatial_Coordinates</span>
            <h2 className="text-5xl lg:text-7xl font-serif text-white mb-10 italic tracking-tighter leading-none">Abuloma <br /><span className="not-italic font-bold text-[#D4AF37]">Flagship.</span></h2>
            
            <p className="text-stone-400 text-lg lg:text-xl font-light leading-relaxed mb-12 border-l border-[#D4AF37]/30 pl-10 italic max-w-lg">
              Synchronize with our architectural grooming destination in Port Harcourt. <br />
              <span className="text-white not-italic font-medium mt-6 block uppercase tracking-wider text-sm lg:text-base">{BUSINESS_INFO.location}</span>
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-16">
              <div className="p-10 border border-white/5 bg-white/[0.01] rounded-2xl hover:bg-white/[0.03] transition-all relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
                <h4 className="text-[7px] font-black uppercase tracking-[0.6em] text-[#D4AF37] mb-6">Master_Link</h4>
                <div className="space-y-4">
                  {BUSINESS_INFO.phones.map((phone, i) => (
                    <p key={i} className="text-white text-sm font-mono tracking-widest hover:text-[#D4AF37] cursor-pointer transition-colors">{phone}</p>
                  ))}
                </div>
              </div>

              <div className="p-10 border border-white/5 bg-white/[0.01] rounded-2xl hover:bg-white/[0.03] transition-all relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
                <h4 className="text-[7px] font-black uppercase tracking-[0.6em] text-[#D4AF37] mb-6">Operational_Window</h4>
                <p className="text-white text-sm font-mono tracking-widest">{BUSINESS_INFO.hours.weekdays}</p>
                <div className="mt-4 flex items-center gap-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                   <span className="text-[8px] text-stone-600 font-black uppercase">Live_Node</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-8">
              <button 
                onClick={syncLocation}
                disabled={isSyncing}
                className="w-full sm:w-auto px-10 py-5 bg-white/[0.03] border border-white/10 text-white text-[10px] font-black uppercase tracking-[0.8em] hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 transition-all flex items-center justify-center gap-4 rounded-full group"
              >
                {isSyncing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin"></div>
                    Syncing_Node...
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4 text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    Initialize_Sync
                  </>
                )}
              </button>

              <a 
                href={userLocation ? `https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${SALON_COORDS.lat},${SALON_COORDS.lng}` : BUSINESS_INFO.mapUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#D4AF37] text-[10px] font-black uppercase tracking-[0.8em] hover:text-white transition-all group flex items-center gap-4 py-2 border-b border-white/5"
              >
                Launch_Navigation <span className="text-xl group-hover:translate-x-3 transition-transform">→</span>
              </a>
            </div>

            {locationError && (
              <p className="mt-6 text-red-500/80 text-[10px] font-black uppercase tracking-widest animate-pulse">{locationError}</p>
            )}
          </div>
          
          <div className="relative aspect-square lg:aspect-video overflow-hidden rounded-[2.5rem] border border-white/10 group shadow-4xl bg-stone-900 order-1 lg:order-2">
             <iframe 
               src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3975.958787837899!2d7.050388675027263!3d4.777065095198244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1069cc81071fdec7%3A0x41eac6b8cebbd393!2s50%20Owudo%20Rd%2C%20Abuloma%2C%20500101%2C%20Rivers!5e0!3m2!1sen!2sng!4v1767361393001!5m2!1sen!2sng" 
               className="w-full h-full border-0 grayscale invert opacity-70 group-hover:opacity-100 group-hover:grayscale-0 group-hover:invert-0 transition-all duration-1000 scale-105" 
               allowFullScreen={true} 
               loading="lazy" 
               referrerPolicy="no-referrer-when-downgrade"
             ></iframe>
             
             {/* Geolocation HUD Overlay */}
             {userLocation && (
               <div className="absolute top-10 left-10 p-6 glass-hd border-white/10 rounded-2xl backdrop-blur-3xl animate-in fade-in zoom-in duration-700">
                  <p className="text-[#D4AF37] text-[8px] font-black uppercase tracking-[0.4em] mb-4">Signal_Locked</p>
                  <div className="space-y-3">
                    <div className="flex justify-between gap-10">
                       <span className="text-stone-500 text-[9px] font-mono">LAT_P:</span>
                       <span className="text-white text-[9px] font-mono">{userLocation.lat.toFixed(5)}</span>
                    </div>
                    <div className="flex justify-between gap-10">
                       <span className="text-stone-500 text-[9px] font-mono">LNG_P:</span>
                       <span className="text-white text-[9px] font-mono">{userLocation.lng.toFixed(5)}</span>
                    </div>
                    <div className="pt-3 border-t border-white/10 flex justify-between gap-10">
                       <span className="text-[#D4AF37] text-[9px] font-black tracking-widest">DIST:</span>
                       <span className="text-white text-[9px] font-black font-mono">{distance} KM</span>
                    </div>
                  </div>
               </div>
             )}

             <div className="absolute inset-0 pointer-events-none border-[1px] border-white/10 m-6 rounded-[2rem]"></div>
             
             {/* Decorative Corner Sights */}
             <div className="absolute top-10 right-10 w-8 h-8 border-t-2 border-r-2 border-[#D4AF37]/40"></div>
             <div className="absolute bottom-10 left-10 w-8 h-8 border-b-2 border-l-2 border-[#D4AF37]/40"></div>
          </div>
        </div>
      </div>

      <style>{`
        .glass-hd {
          background: rgba(10, 10, 10, 0.85);
          backdrop-filter: blur(40px) saturate(180%);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
      `}</style>
    </section>
  );
};

export default InfoSection;
