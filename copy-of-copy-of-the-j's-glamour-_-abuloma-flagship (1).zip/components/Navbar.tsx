
import React, { useState, useEffect } from 'react';
import { BUSINESS_INFO } from '../constants';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Protocols', href: '#services' },
    { label: 'Artisans', href: '#artisans' },
    { label: 'Archive', href: '#portfolio' },
    { label: 'Sync', href: '#booking' },
  ];

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-[120] transition-all duration-700 ease-in-out ${
        isScrolled ? 'py-4 bg-black/80 backdrop-blur-2xl border-b border-[#D4AF37]/20 shadow-[0_4px_30px_rgba(0,0,0,0.5)]' : 'py-8 bg-transparent'
      }`}>
        <div className="max-w-[1600px] mx-auto px-6 lg:px-12 flex justify-between items-center">
          
          <a href="#hero" className="flex items-center gap-4 group">
            <div className="relative w-12 h-12 transition-transform duration-500 group-hover:scale-110">
              <img src={BUSINESS_INFO.logoUrl} alt="Logo" className="w-full h-full object-contain filter drop-shadow-[0_0_8px_rgba(212,175,55,0.6)]" />
            </div>
            <div className="flex flex-col">
              <h1 className="text-white font-serif font-black italic tracking-widest text-lg lg:text-xl leading-none uppercase">
                THE J'S <span className="text-[#D4AF37]">GLAMOUR</span>
              </h1>
              <span className="text-[7px] text-stone-500 font-black uppercase tracking-[0.8em] mt-1 hidden sm:block">Aesthetic Flagship</span>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-12">
            {navItems.map((item) => (
              <a 
                key={item.label} 
                href={item.href} 
                className="text-[10px] font-black uppercase tracking-[0.6em] text-white/50 hover:text-[#D4AF37] transition-all duration-300 relative group"
              >
                {item.label}
                <span className="absolute bottom-[-8px] left-0 w-0 h-[1px] bg-[#D4AF37] group-hover:w-full transition-all duration-500 shadow-[0_0_10px_#D4AF37]"></span>
              </a>
            ))}
            <div className="w-[1px] h-8 bg-white/10 ml-4"></div>
            <div className="flex items-center gap-4 ml-4">
               <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
               <span className="text-[8px] font-mono text-stone-600 tracking-widest uppercase">Live_Node</span>
            </div>
          </nav>

          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-4 bg-white/5 rounded-2xl text-white group"
          >
            <div className="w-6 flex flex-col items-end gap-1.5">
              <div className={`h-[1px] bg-white transition-all duration-500 ${isMenuOpen ? 'w-6 rotate-45 translate-y-[5px]' : 'w-6'}`}></div>
              <div className={`h-[1px] bg-white transition-all duration-500 ${isMenuOpen ? 'w-6 -rotate-45 -translate-y-[5px]' : 'w-4'}`}></div>
            </div>
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 z-[110] bg-[#050505] transition-transform duration-700 ease-[cubic-bezier(0.23,1,0.32,1)] ${
        isMenuOpen ? 'translate-x-0' : 'translate-x-full'
      }`}>
        <div className="h-full flex flex-col justify-center items-center gap-16 p-12">
          <img src={BUSINESS_INFO.logoUrl} className="w-24 h-24 mb-10 drop-shadow-[0_0_20px_#D4AF37]" alt="Logo" />
          <nav className="flex flex-col items-center gap-10">
            {navItems.map((item) => (
              <a 
                key={item.label}
                href={item.href}
                onClick={() => setIsMenuOpen(false)}
                className="text-4xl font-serif text-white italic tracking-tighter hover:text-[#D4AF37] transition-colors"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </div>
    </>
  );
};

export default Navbar;
