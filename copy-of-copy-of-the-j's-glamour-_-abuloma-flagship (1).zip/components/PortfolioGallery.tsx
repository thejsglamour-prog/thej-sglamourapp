
import React, { useState, useMemo, useEffect } from 'react';
import { PORTFOLIO_ITEMS } from '../constants';

const PortfolioGallery: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<'All' | 'Hair' | 'Tattoo' | 'Nails'>('All');
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      // Increased sensitivity for a more pronounced parallax shift
      setMousePos({ 
        x: (e.clientX / window.innerWidth - 0.5) * 25,
        y: (e.clientY / window.innerHeight - 0.5) * 25
      });
    };
    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, []);

  const filteredItems = useMemo(() => {
    if (activeFilter === 'All') return PORTFOLIO_ITEMS;
    return PORTFOLIO_ITEMS.filter(item => item.category === activeFilter);
  }, [activeFilter]);

  return (
    <section id="portfolio" className="py-40 bg-transparent border-t border-white/5 preserve-3d">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 preserve-3d">
        <div className="flex flex-col lg:flex-row items-end justify-between mb-32 gap-12">
          <div className="translate-z-[100px]">
             <span className="text-[#D4AF37] font-bold uppercase tracking-[1.2em] text-[10px] mb-6 block">Spatial_Archive</span>
             <h2 className="text-5xl lg:text-7xl font-serif text-white tracking-tighter italic leading-none">The <span className="not-italic font-bold">Lookbook.</span></h2>
          </div>

          <div className="flex flex-wrap gap-10 border-b border-white/5 pb-4 translate-z-[50px]">
            {(['All', 'Hair', 'Tattoo', 'Nails'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`text-[10px] font-black uppercase tracking-[0.6em] transition-all relative py-2 ${
                  activeFilter === filter ? 'text-[#D4AF37]' : 'text-stone-500 hover:text-white'
                }`}
              >
                {filter}
                {activeFilter === filter && <div className="absolute bottom-[-1px] left-0 w-full h-[2px] bg-[#D4AF37] shadow-[0_0_10px_#D4AF37]"></div>}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 lg:gap-24 preserve-3d">
          {filteredItems.map((item, idx) => {
            // Pronounced rhythmic Z-offset for static depth
            const baseZ = (idx % 3) * 45; 
            return (
              <div 
                key={item.id}
                className="group relative h-[650px] preserve-3d transition-transform duration-700 hover:z-[100]"
                style={{ 
                  transform: `perspective(2000px) rotateX(${-mousePos.y * 0.5}deg) rotateY(${mousePos.x * 0.5}deg) translateZ(${baseZ}px)`
                }}
              >
                {/* 3D Frame Base - Deep Recess */}
                <div className="absolute inset-0 bg-[#050505] border border-white/10 shadow-2xl transition-all duration-700 group-hover:border-[#D4AF37]/50 group-hover:shadow-[0_80px_150px_rgba(0,0,0,0.9)] translate-z-[-60px]"></div>
                
                {/* Parallax Image Layer - Recessed Deeper */}
                <div 
                  className="absolute inset-4 overflow-hidden bg-stone-900 transition-transform duration-500 ease-out"
                  style={{ transform: `translate3d(${mousePos.x * 0.8}px, ${mousePos.y * 0.8}px, -100px)` }}
                >
                  <img 
                    src={item.imageUrl} 
                    alt={item.title}
                    className="w-full h-full object-cover grayscale opacity-40 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-[3s] group-hover:scale-125"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-90 group-hover:opacity-40 transition-opacity"></div>
                </div>

                {/* Mid-Depth UI Details */}
                <div 
                  className="absolute inset-0 pointer-events-none border border-white/5 m-8 translate-z-[20px] transition-all duration-700 group-hover:border-[#D4AF37]/20"
                  style={{ transform: `translate3d(${-mousePos.x * 0.3}px, ${-mousePos.y * 0.3}px, 20px)` }}
                ></div>

                {/* Annotation Layer - Floating Significantly Forward */}
                <div 
                  className="absolute inset-0 p-12 flex flex-col justify-end pointer-events-none transition-transform duration-500 ease-out"
                  style={{ transform: `translate3d(${-mousePos.x * 1.5}px, ${-mousePos.y * 1.5}px, 150px)` }}
                >
                   <div className="mb-6 flex items-center gap-4 overflow-hidden">
                      <div className="w-12 h-px bg-[#D4AF37] shadow-[0_0_10px_#D4AF37]"></div>
                      <span className="text-[#D4AF37] text-[10px] font-black uppercase tracking-[0.8em] whitespace-nowrap">NODE_{idx + 100}</span>
                   </div>
                   <h3 className="text-4xl lg:text-5xl font-serif text-white italic leading-tight group-hover:text-[#D4AF37] transition-colors drop-shadow-2xl">{item.title}</h3>
                   <div className="mt-6 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-all duration-700 translate-y-8 group-hover:translate-y-0">
                      <p className="text-stone-400 text-[9px] font-black uppercase tracking-[1em]">Aesthetic_Blueprint_v4</p>
                      <div className="flex gap-1">
                         {[1,2,3,4,5].map(i => <div key={i} className="w-1 h-1 bg-[#D4AF37]/40 rounded-full"></div>)}
                      </div>
                   </div>
                </div>

                {/* HUD Decor - Corner Precise Elements */}
                <div 
                  className="absolute top-8 right-8 flex flex-col items-end opacity-30 group-hover:opacity-100 transition-opacity"
                  style={{ transform: `translate3d(${mousePos.x}px, ${mousePos.y}px, 200px)` }}
                >
                   <div className="text-[10px] font-mono text-white/50 tracking-[0.5em] mb-2">{item.category.toUpperCase()}</div>
                   <div className="w-6 h-6 border-r-2 border-t-2 border-[#D4AF37]/40"></div>
                </div>
                
                <div className="absolute bottom-8 left-8 w-6 h-6 border-l-2 border-b-2 border-[#D4AF37]/40 opacity-30 group-hover:opacity-100 transition-opacity translate-z-[200px]"></div>
              </div>
            );
          })}
        </div>

        <div className="mt-48 text-center translate-z-[200px]">
           <button className="group relative px-20 py-8 border border-white/10 text-[11px] font-black text-white/40 hover:text-black hover:bg-white uppercase tracking-[1.5em] transition-all shadow-4xl overflow-hidden">
              <span className="relative z-10">Access Infinite Archive</span>
              <div className="absolute inset-0 bg-[#D4AF37] translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
           </button>
        </div>
      </div>
    </section>
  );
};

export default PortfolioGallery;
