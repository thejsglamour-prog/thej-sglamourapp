
import React, { useState, useEffect } from 'react';
import { SERVICES, STYLISTS } from '../constants';
import { BookingFormData } from '../types';
import { API } from '../services/api';

const BookingForm: React.FC = () => {
  const [formData, setFormData] = useState<BookingFormData>({
    name: '', email: '', phone: '', service: '', stylist: '', date: '', time: '', notes: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);

  useEffect(() => {
    const handlePreSelect = (e: any) => {
      if (e.detail?.stylistName) {
        setFormData(prev => ({ ...prev, stylist: e.detail.stylistName }));
        document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
      }
    };
    window.addEventListener('preSelectStylist', handlePreSelect);
    return () => window.removeEventListener('preSelectStylist', handlePreSelect);
  }, []);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError(null);

    if (!validateEmail(formData.email)) {
      setEmailError("Invalid email protocol detected.");
      return;
    }

    setLoading(true);
    try {
      await API.processBooking(formData);
      setIsSubmitted(true);
      setLoading(false);
      // Clean up form after delay or on success
      setTimeout(() => {
        document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      setLoading(false);
      alert("Synchronization failure. System node unreachable.");
    }
  };

  const inputClasses = `w-full bg-transparent border-b border-white/10 py-4 lg:py-6 text-white outline-none transition-all placeholder-stone-800 text-sm lg:text-base tracking-widest hover:border-[#D4AF37]/50 focus:border-[#D4AF37] disabled:opacity-50`;

  return (
    <section id="booking" className="py-24 lg:py-48 bg-[#0a0a0a] border-y border-white/10 relative overflow-hidden scroll-mt-24">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24 items-start">
        
        <div className="lg:col-span-5 flex flex-col items-center lg:items-start text-center lg:text-left">
          <span className="text-[#D4AF37] font-bold uppercase tracking-[1em] text-[10px] mb-8 block">Registry_Activation</span>
          <h2 className="text-5xl md:text-6xl lg:text-[8rem] font-serif text-white italic leading-[0.85] mb-12 tracking-tighter">
            The <br className="hidden lg:block" />Registry.
          </h2>
          <p className="text-stone-500 text-lg lg:text-2xl font-light mb-12 italic leading-relaxed max-w-md">
            Geometric Precision, Refined Finishing. Synchronize your parameters to initialize transformation at the Abuloma flagship.
          </p>
          <div className="flex items-center gap-4 text-white/20">
             <div className="w-12 h-px bg-white/20"></div>
             <span className="text-[10px] font-mono uppercase tracking-[0.5em]">PHC_NODE_V10</span>
          </div>
        </div>

        <div className="lg:col-span-7 glass-hd p-8 lg:p-20 border border-white/5 shadow-[0_80px_160px_rgba(0,0,0,0.8)] relative rounded-3xl overflow-hidden backdrop-blur-3xl">
          {isSubmitted ? (
            <div className="py-20 lg:py-32 text-center animate-in fade-in slide-in-from-bottom-8 duration-1000">
               <div className="w-24 h-24 bg-[#D4AF37] rounded-full flex items-center justify-center mx-auto mb-12 shadow-[0_0_60px_rgba(212,175,55,0.4)]">
                  <svg className="w-12 h-12 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
                  </svg>
               </div>
               <h3 className="text-4xl lg:text-6xl font-serif text-white mb-6 italic tracking-tighter">Protocol Authorized.</h3>
               <p className="text-stone-400 text-xs font-black uppercase tracking-[0.6em] mb-16">Master Sequence Initialized</p>
               <button 
                onClick={() => setIsSubmitted(false)} 
                className="text-[#D4AF37] text-[11px] font-black tracking-[1.2em] uppercase border border-[#D4AF37]/40 px-12 py-5 hover:bg-[#D4AF37] hover:text-black transition-all duration-500 rounded-full"
               >
                 Return_To_Entry
               </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-10 lg:gap-14">
              <div className="sm:col-span-1">
                <input required value={formData.name} onChange={(e)=>setFormData({...formData, name: e.target.value})} className={inputClasses} placeholder="LEGAL FULL NAME" />
              </div>
              <div className="sm:col-span-1 relative">
                <input required type="email" value={formData.email} onChange={(e)=>{setFormData({...formData, email: e.target.value}); setEmailError(null);}} className={`${inputClasses} ${emailError ? 'border-red-500/50' : ''}`} placeholder="SECURE EMAIL" />
                {emailError && <span className="absolute -bottom-6 left-0 text-red-500 text-[10px] font-black uppercase tracking-widest">{emailError}</span>}
              </div>
              <div className="sm:col-span-1">
                <input required type="tel" value={formData.phone} onChange={(e)=>setFormData({...formData, phone: e.target.value})} className={inputClasses} placeholder="PHONE CHANNEL" />
              </div>
              <div className="sm:col-span-1">
                <select required value={formData.service} onChange={(e)=>setFormData({...formData, service: e.target.value})} className={inputClasses}>
                  <option value="" className="bg-stone-900">CHOOSE PROTOCOL</option>
                  {SERVICES.map(s => <option key={s.id} value={s.name} className="bg-stone-900">{s.name.toUpperCase()}</option>)}
                </select>
              </div>
              <div className="sm:col-span-1">
                <select required value={formData.stylist} onChange={(e)=>setFormData({...formData, stylist: e.target.value})} className={inputClasses}>
                  <option value="" className="bg-stone-900">SELECT MASTER ARTISAN</option>
                  {STYLISTS.map(s => <option key={s.id} value={s.name} className="bg-stone-900">{s.name.toUpperCase()}</option>)}
                </select>
              </div>
              <div className="sm:col-span-1">
                <input required type="date" value={formData.date} onChange={(e)=>setFormData({...formData, date: e.target.value})} className={inputClasses + " invert-calendar"} />
              </div>
              <div className="sm:col-span-2">
                <input required type="time" value={formData.time} onChange={(e)=>setFormData({...formData, time: e.target.value})} className={inputClasses} />
              </div>
              <button 
                type="submit" 
                disabled={loading} 
                className="sm:col-span-2 mt-10 py-8 bg-white text-black font-black uppercase tracking-[1.5em] text-[12px] hover:bg-[#D4AF37] hover:text-white transition-all duration-700 shadow-4xl disabled:opacity-50 relative group overflow-hidden"
              >
                <span className="relative z-10">{loading ? 'SYNCHRONIZING_NODE...' : 'INITIALIZE_PROTOCOL'}</span>
                <div className="absolute inset-0 bg-stone-900 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
              </button>
            </form>
          )}
        </div>
      </div>
      <style>{`.invert-calendar::-webkit-calendar-picker-indicator { filter: invert(1); cursor: pointer; }`}</style>
    </section>
  );
};

export default BookingForm;
