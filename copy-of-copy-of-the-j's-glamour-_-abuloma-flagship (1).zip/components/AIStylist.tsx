
import React, { useState, useRef, useEffect } from 'react';
import { getStyleAdviceStream } from '../services/gemini';
import { ChatMessage } from '../types';

const DISCOVERY_PROMPTS = [
  "Geometric Precision fades",
  "Dreadlock maintenance protocol",
  "Refined Finishing for nails",
  "Artisan tattoo consultation"
];

const AIStylist: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: `Consultation Desk active. How shall we redefine your aesthetic today?` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, streamingText, isLoading]);

  const handleReset = () => {
    setMessages([{ role: 'model', text: `Neural cache cleared. Re-initializing consultation desk... How may I assist you?` }]);
    setInput('');
  };

  const handleSend = async (customText?: string) => {
    const textToSend = customText || input.trim();
    if (!textToSend || isLoading) return;

    const newUserMessage: ChatMessage = { role: 'user', text: textToSend };
    const updatedHistory = [...messages, newUserMessage];

    setInput('');
    setMessages(updatedHistory);
    setIsLoading(true);
    setStreamingText('');

    let fullResponse = '';
    const stream = getStyleAdviceStream(updatedHistory);

    try {
      for await (const chunk of stream) {
        fullResponse += chunk;
        setStreamingText(fullResponse);
      }
      setMessages(prev => [...prev, { role: 'model', text: fullResponse }]);
      setStreamingText('');
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "Protocol error: Connection to Abuloma Node timed out. Please retry." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="ai-consultant" className="py-24 lg:py-40 bg-[#050505] relative overflow-hidden">
      {/* Decorative ambient elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-[#D4AF37]/5 to-transparent pointer-events-none"></div>
      
      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <div className="mb-16 lg:mb-24 flex flex-col md:flex-row justify-between items-end gap-8">
          <div className="max-w-xl">
            <span className="text-[#D4AF37] font-bold uppercase tracking-[1.2em] text-[10px] mb-6 block">Intelligence Node</span>
            <h2 className="text-4xl lg:text-7xl font-serif text-white italic tracking-tighter leading-none">
              Style <span className="not-italic font-bold">Concierge.</span>
            </h2>
            <p className="text-stone-500 text-xs lg:text-sm uppercase tracking-widest mt-8 max-w-sm leading-relaxed border-l border-white/10 pl-8">
              Synchronize with our Master AI for elite grooming advice, structural analysis, and protocol optimization.
            </p>
          </div>
          <button 
            onClick={handleReset}
            className="text-stone-600 text-[9px] font-black uppercase tracking-widest hover:text-[#D4AF37] transition-all flex items-center gap-3 py-2 border-b border-white/5"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
            Reset_Protocol
          </button>
        </div>

        <div className="bg-[#0a0a0a] border border-white/5 shadow-[0_100px_200px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col h-[600px] lg:h-[750px] rounded-3xl relative">
          {/* Dashboard Header */}
          <div className="px-8 lg:px-10 py-5 bg-stone-900/40 border-b border-white/5 flex items-center justify-between shrink-0 backdrop-blur-xl">
            <div className="flex items-center gap-4">
              <div className="w-2 h-2 rounded-full bg-[#D4AF37] animate-pulse shadow-[0_0_15px_#D4AF37]"></div>
              <div className="flex flex-col">
                <span className="text-[9px] font-black text-white/60 uppercase tracking-[0.4em]">Node: ABULOMA_CORE_PHC</span>
                <span className="text-[7px] font-mono text-stone-700 uppercase tracking-widest mt-0.5">Latency: 14ms // Secure Link Established</span>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-3">
              <span className="px-2 py-0.5 border border-white/10 rounded-sm text-[6px] font-mono text-stone-500 tracking-widest uppercase">Encryption: AES-256</span>
              <span className="text-[7px] font-black text-white/30 uppercase tracking-widest">Protocol V4.1.2</span>
            </div>
          </div>

          {/* Chat Interface Container */}
          <div className="flex-grow flex flex-col overflow-hidden relative">
            <div 
              ref={scrollRef}
              className="flex-grow overflow-y-auto p-8 lg:p-14 space-y-10 scroll-smooth no-scrollbar"
            >
              {messages.map((msg, idx) => (
                <div 
                  key={idx} 
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}
                >
                  <div className={`max-w-[85%] lg:max-w-[70%] relative ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                    {msg.role === 'model' && (
                      <span className="text-[7px] font-black text-[#D4AF37] uppercase tracking-[0.5em] mb-3 block opacity-50">Master_AI // Concierge</span>
                    )}
                    <div className={`px-6 py-5 border ${
                      msg.role === 'user' 
                        ? 'border-white/10 bg-white/[0.03] text-white text-[10px] lg:text-[12px] font-black uppercase tracking-wider leading-relaxed rounded-2xl rounded-tr-none' 
                        : 'border-[#D4AF37]/20 bg-[#D4AF37]/5 text-stone-200 text-sm lg:text-lg font-serif italic leading-relaxed rounded-2xl rounded-tl-none shadow-2xl backdrop-blur-sm'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                </div>
              ))}
              
              {streamingText && (
                <div className="flex justify-start animate-in fade-in duration-300">
                  <div className="max-w-[85%] lg:max-w-[70%] text-left">
                    <span className="text-[7px] font-black text-[#D4AF37] uppercase tracking-[0.5em] mb-3 block opacity-50">Master_AI // Processing</span>
                    <div className="px-6 py-5 border border-[#D4AF37]/20 bg-[#D4AF37]/5 text-stone-200 text-sm lg:text-lg font-serif italic leading-relaxed rounded-2xl rounded-tl-none">
                      {streamingText}
                      <span className="inline-block w-1.5 h-4 bg-[#D4AF37] ml-2 animate-pulse align-middle"></span>
                    </div>
                  </div>
                </div>
              )}

              {isLoading && !streamingText && (
                <div className="flex justify-start">
                  <div className="flex gap-2.5 p-6 glass-hd border-white/5 rounded-2xl">
                    <div className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-[#D4AF37] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  </div>
                </div>
              )}
            </div>

            {/* Input Overlay */}
            <div className="p-8 lg:p-12 border-t border-white/5 bg-stone-900/30 backdrop-blur-2xl shrink-0">
              <div className="flex flex-wrap gap-3 mb-8">
                {!isLoading && messages.length < 5 && DISCOVERY_PROMPTS.map((prompt) => (
                  <button 
                    key={prompt}
                    onClick={() => handleSend(prompt)}
                    className="px-4 py-2 border border-white/5 text-[8px] lg:text-[10px] font-black uppercase tracking-widest text-stone-500 hover:text-white hover:border-[#D4AF37]/40 hover:bg-[#D4AF37]/5 transition-all rounded-full"
                  >
                    {prompt}
                  </button>
                ))}
              </div>

              <div className="relative flex items-center">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="INPUT AESTHETIC REQUEST..."
                  className="w-full bg-transparent border-b border-white/10 py-5 lg:py-6 text-[10px] lg:text-[12px] font-black tracking-[0.4em] text-white outline-none focus:border-[#D4AF37] transition-all placeholder-stone-800 pr-24"
                  disabled={isLoading}
                />
                <button 
                  onClick={() => handleSend()}
                  disabled={isLoading || !input.trim()}
                  className="absolute right-0 text-[10px] font-black text-[#D4AF37] uppercase tracking-[0.3em] hover:text-white transition-all disabled:opacity-20 flex items-center gap-3 group/send"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Execute</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                </button>
              </div>
              <p className="mt-6 text-[7px] font-mono text-stone-700 uppercase tracking-widest text-center">
                System Authorized: Abuloma Node V9.2 // Port Harcourt Flagship Secure
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIStylist;
