import { GoogleGenAI } from "@google/genai";

export const handler = async (event: any) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method Not Allowed' }) };
  }

  // API Key is fetched from environment variable defined in Netlify dashboard
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'API_KEY environment variable is not configured' }) };
  }

  try {
    const { contents } = JSON.parse(event.body);
    const ai = new GoogleGenAI({ apiKey });
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: "You are the 'Master AI Concierge' at THE J'S GLAMOUR, an elite unisex salon flagship in Abuloma, Port Harcourt. Philosophies: 1. GEOMETRIC PRECISION. 2. REFINED FINISHING. Persona: clinical, sophisticated, high-end. Keep responses under 60 words. Encourage physical consultation with Master Director, Jerroo Favour (an Osemenge descendant).",
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
      },
    });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text: response.text }),
    };
  } catch (error: any) {
    console.error("AI Node Failure:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Aesthetic calibration failed. Please try again." }),
    };
  }
};