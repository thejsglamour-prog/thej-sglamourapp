import { ChatMessage } from "../types";

export async function* getStyleAdviceStream(history: ChatMessage[]) {
  try {
    const contents = history.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const response = await fetch('/.netlify/functions/genai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `Server error: ${response.status}`);
    }

    const data = await response.json();
    if (data.text) {
      // Yielding the full text at once since the standard Netlify function isn't streaming,
      // but keeping the generator pattern for frontend compatibility.
      yield data.text;
    }
  } catch (error: any) {
    console.error("AI Node Failure:", error);
    yield `Aesthetic calibration interrupted: ${error.message || "Connection lost"}. Please refresh the protocol or contact the flagship node.`;
  }
}