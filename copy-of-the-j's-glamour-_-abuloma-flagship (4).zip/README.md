<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# THE J'S GLAMOUR | HD 3D Aesthetic Flagship

Premium hair, beauty, and grooming architecture for the sovereign elite of Port Harcourt. This application fuses high-end aesthetics with Gemini-powered intelligence for a seamless luxury concierge experience.

## Technical Architecture

- **Frontend**: React 19 + Vite 6
- **Styling**: Tailwind CSS 4 + 3D CSS Transforms
- **Intelligence**: Gemini 3 Flash Preview (Streaming enabled)
- **State**: Virtual Persistent Backend (LocalStorage Node)

## Run Locally

**Prerequisites:**  Node.js (v18+)

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure Node Env:**
   Set the `API_KEY` in your environment or a local `.env` file (not committed).
   ```bash
   export API_KEY="your_actual_gemini_api_key"
   ```

3. **Verify AI Node:**
   Run the smoke test to ensure neural handshakes are stable.
   ```bash
   node scripts/smoke-test.js
   ```

4. **Launch Application:**
   ```bash
   npm run dev
   ```

## Registry Protocols

Clients can synchronize with the Abuloma node via **The Lookbook** or the **Registry Activation** portal. The Master AI Concierge performs real-time aesthetic analysis for every booking protocol initialized.

## System Admin

Access the **Concierge Dashboard** via the "System_Admin_Access" link in the footer to monitor:
- Live Registry Queue
- Node Latency & System Metrics
- Revenue Projections
- Real-time Protocol Telemetry

---
&copy; 2024 THE J'S GLAMOUR // PHC_NODE_V10.2