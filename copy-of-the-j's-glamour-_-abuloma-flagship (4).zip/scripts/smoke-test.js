#!/usr/bin/env node
/**
 * THE J'S GLAMOUR - AI Smoke Test
 * Verifies GenAI SDK configuration and response stability.
 */
import { GoogleGenAI } from "@google/genai";

const runTest = async () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey || apiKey === 'PLACEHOLDER_API_KEY') {
    console.error("❌ ERROR: API_KEY is not set in environment.");
    process.exit(1);
  }

  console.log("🚀 Initializing AI Node...");
  const ai = new GoogleGenAI({ apiKey });

  try {
    console.log("📡 Dispatching test sequence (gemini-3-flash-preview)...");
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Perform a system check. Respond with 'NODE_ACTIVE' and a 5-word greeting.",
    });

    console.log("✅ RESPONSE RECVD:");
    console.log("-------------------");
    console.log(response.text);
    console.log("-------------------");
    console.log("🏁 Smoke test complete.");
  } catch (err) {
    console.error("❌ CRITICAL FAILURE:", err.message);
    process.exit(1);
  }
};

runTest();