import { Service, Stylist } from './types';

export const OFFICIAL_LOGO = '/assets/logo.png';

export const BUSINESS_INFO = {
  name: "THE J'S GLAMOUR",
  tagline: "Premium Hair & Beauty Salon",
  logoUrl: OFFICIAL_LOGO,
  description: "Port Harcourt's ultimate grooming sanctuary. We fuse technical mastery with elite aesthetics to deliver high-definition beauty transformations in Abuloma.",
  location: "#50 Owudo Street off Bitter Leaf Road, Abuloma, Port Harcourt",
  mapUrl: "https://maps.app.goo.gl/tsMKxSks7THYZZJd8",
  email: "thejsglamour@gmail.com",
  rating: 5.0,
  reviewsCount: 25,
  hours: {
    weekdays: "08:00 – 21:00",
    saturday: "08:00 – 21:00",
    sunday: "12:00 – 21:00"
  },
  phones: ["09011846464", "07048664579"],
  whatsapp: "2349011846464"
};

export const SERVICES: Service[] = [
  { 
    id: '1', 
    name: 'Elite Barbering', 
    description: 'Master-level fades and structural styling with gold-standard precision.', 
    category: 'Hair', 
    price: '₦3,500+', 
    icon: 'scissors',
    imageUrl: 'https://images.unsplash.com/photo-1621605815841-2dddbd274733?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '2', 
    name: 'Geometric Braids', 
    description: 'Complex structural patterns with absolute master-class detailing.', 
    category: 'Hair', 
    price: '₦7,000+', 
    icon: 'brush',
    imageUrl: 'https://images.unsplash.com/photo-1632765854612-9b02b6ec2b15?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '3', 
    name: 'Artistic Ink', 
    description: 'Precision realism and pigment art in a high-fidelity sterile environment.', 
    category: 'Grooming', 
    price: '₦20,000+', 
    icon: 'brush',
    imageUrl: 'https://images.unsplash.com/photo-1590210350293-6a635836853e?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '4', 
    name: 'Nail Architecture', 
    description: 'Advanced gel pigments and high-gloss metallic refined finishes.', 
    category: 'Beauty', 
    price: '₦5,000+', 
    icon: 'sparkles',
    imageUrl: 'https://images.unsplash.com/photo-1604654894610-df4906821603?auto=format&fit=crop&q=80&w=800'
  }
];

export const STYLISTS: Stylist[] = [
  {
    id: 'ceo-01',
    name: 'FAVOUR TAMUNO BRIGHT (JERROO)',
    role: 'C.E.O / VISIONARY DIRECTOR / OSEMENGE DESCENDANT',
    bio: 'Jerroo Favour Bright is the visionary lead of THE J\'S GLAMOUR. Often seen at the Abuloma flagship, he embodies the "Urban Elite" aesthetic—mixing high-fashion streetwear with the geometric precision of master barbering. His leadership as an Osemenge descendant brings a unique cultural heritage to the Port Harcourt grooming scene, establishing a new gold standard for refined finishing.',
    specialty: 'Management',
    imageUrl: '/assets/ceo.jpg'
  }
];

export const PORTFOLIO_ITEMS = [
  { 
    id: 'p1', 
    title: 'Surgical Taper', 
    category: 'Hair', 
    imageUrl: 'https://images.unsplash.com/photo-1592647420248-b74a217f7b17?auto=format&fit=crop&q=80&w=800', 
    isHero: true 
  },
  { 
    id: 'p2', 
    title: 'Refined Gold Nails', 
    category: 'Nails', 
    imageUrl: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&q=80&w=1200', 
    isHero: false 
  },
  { 
    id: 'p3', 
    title: 'Precision Line Ink', 
    category: 'Tattoo', 
    imageUrl: 'https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?auto=format&fit=crop&q=80&w=800', 
    isHero: false 
  }
];