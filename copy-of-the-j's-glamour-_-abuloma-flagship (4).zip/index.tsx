import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Robust Service Worker registration for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      // Service workers are served from the root to control the entire origin scope
      const swUrl = '/service-worker.js';
      const registration = await navigator.serviceWorker.register(swUrl);
      
      registration.onupdatefound = () => {
        const installingWorker = registration.installing;
        if (installingWorker) {
          installingWorker.onstatechange = () => {
            if (installingWorker.state === 'installed') {
              if (navigator.serviceWorker.controller) {
                console.log('New content available; please refresh.');
              } else {
                console.log('Content is cached for offline use.');
              }
            }
          };
        }
      };
      
      console.log('SW registered successfully with scope:', registration.scope);
    } catch (err) {
      console.warn('SW registration failed:', err);
    }
  });
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);