
import React, { useState } from 'react';
import { SERVICES } from '../constants';

const ServicesGrid: React.FC = () => {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section id="services" className="py-32 lg:py-64 bg-transparent preserve-3d relative">
      <div className="absolute top-1/3 lg:top-1/4 left-1/2 -translate-x-1/2 text-white/5 text-[15vw] lg:text-[20vw] font-black tracking-widest pointer-events-none select-none uppercase whitespace-nowrap">
        Engineered
      </div>

      <div className="max-w-[1800px] mx-auto px-6 lg:px-12 relative z-10 preserve-3d">
        <div className="mb-24 lg:mb-48 flex flex-col items-center translate-z-[50px]">
          <span className="text-[#D4AF37] font-bold uppercase tracking-[1.5em] text-[12px] lg:text-[14px] mb-6 lg:mb-8 block">Operational_Protocols</span>
          <h2 className="text-5xl lg:text-[11rem] font-serif text-white italic tracking-tighter text-center leading-[0.9] lg:leading-[0.8] drop-shadow-2xl">
            Aesthetic <br />
            <span className="not-italic font-bold text-[#D4AF37]">Architect.</span>
          </h2>
          <div className="w-48 lg:w-80 h-[2px] lg:h-[3px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent mt-12 lg:mt-20 shadow-[0_0_40px_#D4AF37]"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10 lg:gap-20 preserve-3d">
          {SERVICES.map((service, idx) => (
            <div 
              key={service.id} 
              onMouseEnter={() => setHoveredIndex(idx)}
              onMouseLeave={() => setHoveredIndex(null)}
              className="perspective-card group h-[550px] lg:h-[650px] relative preserve-3d cursor-pointer"
            >
              <div 
                className={`w-full h-full glass-hd p-10 lg:p-16 flex flex-col justify-between transition-all duration-700 ease-out relative rounded-2xl overflow-hidden ${
                  hoveredIndex === idx ? 'shadow-[0_50px_100px_rgba(0,0,0,1)]' : 'shadow-xl'
                }`}
                style={{
                  transform: hoveredIndex === idx 
                    ? 'perspective(2000px) rotateX(10deg) rotateY(-5deg) translateZ(80px)' 
                    : 'perspective(2000px) rotateX(0) rotateY(0) translateZ(0)'
                }}
              >
                <div className="absolute inset-0 -z-20 overflow-hidden">
                  {service.imageUrl && (
                    <img 
                      src={service.imageUrl} 
                      alt={service.name} 
                      className={`w-full h-full object-cover transition-all duration-[1.5s] ease-out ${
                        hoveredIndex === idx ? 'scale-125 grayscale-0 opacity-100' : 'scale-110 grayscale opacity-30'
                      }`}
                    />
                  )}
                  <div className={`absolute inset-0 transition-opacity duration-700 ${
                    hoveredIndex === idx ? 'bg-black/60' : 'bg-gradient-to-b from-black/90 via-black/40 to-black/90'
                  }`}></div>
                </div>

                <div className="z-10">
                  <div className="w-16 h-16 lg:w-20 lg:h-20 glass-hd flex items-center justify-center mb-10 lg:mb-16 border-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-black transition-all duration-500">
                    <span className="text-[14px] lg:text-[18px] font-mono font-black italic">JG_{idx + 1}</span>
                  </div>
                  <h3 className="text-4xl lg:text-6xl font-serif text-white mb-6 lg:mb-10 group-hover:text-[#D4AF37] transition-colors leading-[0.9] tracking-tighter italic">
                    {service.name}
                  </h3>
                  <p className="text-stone-200 text-sm lg:text-xl leading-relaxed font-light italic opacity-70 group-hover:opacity-100 transition-opacity max-w-[320px]">
                    {service.description}
                  </p>
                </div>

                <div className="flex items-center justify-between border-t border-white/20 pt-10 lg:pt-14 z-10">
                  <div className="flex flex-col">
                    <span className="text-[#D4AF37] font-black text-xl lg:text-2xl uppercase tracking-widest drop-shadow-[0_0_10px_#D4AF37]">{service.price}</span>
                    <span className="text-white/40 text-[9px] font-black uppercase tracking-[0.4em] mt-1 lg:mt-2">Protocol_Base</span>
                  </div>
                  <a href="#booking" className="text-[12px] lg:text-[14px] font-black uppercase tracking-[0.6em] text-white group-hover:text-[#D4AF37] transition-all flex items-center gap-4 lg:gap-6">
                    LAUNCH <span className="text-xl lg:text-2xl">→</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesGrid;
