
import React, { useState, useEffect } from 'react';
import { BUSINESS_INFO } from '../constants';

const Hero: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setIsLoaded(true);
    const handleMove = (e: MouseEvent) => {
      setMousePos({ 
        x: (e.clientX / window.innerWidth - 0.5) * 30,
        y: (e.clientY / window.innerHeight - 0.5) * 30
      });
    };
    window.addEventListener('mousemove', handleMove);
    return () => window.removeEventListener('mousemove', handleMove);
  }, []);

  return (
    <section id="hero" className="relative min-h-[100vh] flex items-center justify-center pt-24 lg:pt-32 overflow-hidden bg-transparent preserve-3d">
      <div className="max-w-[1600px] w-full mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center z-10 preserve-3d">
        
        <div className={`transition-all duration-[1.5s] ease-out flex flex-col items-center lg:items-start text-center lg:text-left ${isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 lg:-translate-x-20'}`}>
          <div className="flex items-center gap-4 lg:gap-6 mb-8 lg:mb-12">
            <span className="text-[#D4AF37] font-black uppercase tracking-[1em] text-[10px] lg:text-[12px] animate-pulse">EST_2024</span>
            <div className="h-[1px] w-12 lg:w-24 bg-[#D4AF37]/40 shadow-[0_0_10px_#D4AF37]"></div>
          </div>
          
          <h1 className="text-5xl md:text-7xl lg:text-[7rem] xl:text-[9rem] font-serif font-light text-white leading-[1] lg:leading-[0.85] mb-8 lg:mb-12 tracking-tighter drop-shadow-2xl">
            Elite <br />
            <span className="italic font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-[#D4AF37] to-white/30">Mastery.</span>
          </h1>

          <p className="text-stone-300 text-lg md:text-xl lg:text-2xl font-light italic leading-relaxed max-w-lg mb-12 lg:mb-16 lg:border-l-4 border-[#D4AF37] lg:pl-10 translate-z-[50px]">
            High-definition grooming architecture for the sovereign elite of Port Harcourt.
          </p>

          <div className="flex flex-col sm:flex-row items-center gap-8 lg:gap-10 w-full lg:w-auto">
            <a 
              href="#booking" 
              className="w-full sm:w-auto px-12 lg:px-16 py-6 lg:py-8 bg-white text-black font-black uppercase tracking-[0.8em] text-[11px] lg:text-[12px] hover:bg-[#D4AF37] hover:text-white transition-all duration-500 shadow-4xl group relative overflow-hidden text-center"
            >
              <span className="relative z-10">Sync Entry</span>
              <div className="absolute inset-0 bg-stone-900 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            </a>
            
            <div className="flex flex-col items-center lg:items-start gap-1">
               <span className="text-[9px] font-black text-stone-600 tracking-[0.4em] uppercase">Abuloma Node</span>
               <span className="text-white/60 text-[12px] lg:text-[14px] font-mono tracking-widest">{BUSINESS_INFO.phones[0]}</span>
            </div>
          </div>
        </div>

        <div className="relative h-[350px] md:h-[500px] lg:h-[800px] flex items-center justify-center preserve-3d">
           <div 
            className="w-[260px] h-[260px] md:w-[400px] md:h-[400px] lg:w-[600px] lg:h-[600px] rounded-[3rem] lg:rounded-[4rem] border border-white/5 bg-gradient-to-br from-white/10 to-transparent backdrop-blur-3xl transition-transform duration-700 ease-out flex items-center justify-center shadow-4xl relative overflow-visible"
            style={{ transform: `perspective(2000px) rotateX(${-mousePos.y * 0.1}deg) rotateY(${mousePos.x * 0.1}deg)` }}
           >
              <div 
                className="w-32 h-32 md:w-56 md:h-56 lg:w-80 lg:h-80 drop-shadow-[0_40px_100px_rgba(212,175,55,0.8)] transition-transform duration-500 hover:scale-110"
                style={{ transform: `translate3d(${mousePos.x * 0.4}px, ${mousePos.y * 0.4}px, 100px)` }}
              >
                 <img src={BUSINESS_INFO.logoUrl} alt="3D Logo" className="w-full h-full object-contain" />
              </div>

              <div className="absolute inset-[-20px] lg:inset-[-40px] border border-[#D4AF37]/20 rounded-full animate-slow-spin opacity-50"></div>
              <div className="absolute inset-[-40px] lg:inset-[-80px] border border-white/5 rounded-full animate-slow-spin-reverse opacity-20"></div>
           </div>
        </div>
      </div>
      
      <style>{`
        @keyframes slow-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @keyframes slow-spin-reverse { from { transform: rotate(360deg); } to { transform: rotate(0deg); } }
        .animate-slow-spin { animation: slow-spin 30s linear infinite; }
        .animate-slow-spin-reverse { animation: slow-spin-reverse 45s linear infinite; }
      `}</style>
    </section>
  );
};

export default Hero;
