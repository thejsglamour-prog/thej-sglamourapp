
import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import { Stylist } from '../types';

const InstagramIcon = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
  </svg>
);

const StylistsSection: React.FC = () => {
  const [stylist, setStylist] = useState<Stylist | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStylist = async () => {
      const data = await API.getStylists();
      // Feature exclusively the CEO (Favour Tamuno Bright)
      const ceo = data.find(s => s.id === 'ceo-01');
      if (ceo) {
        setStylist(ceo);
      } else if (data.length > 0) {
        setStylist(data[0]);
      }
      setLoading(false);
    };
    fetchStylist();
  }, []);

  if (loading || !stylist) return null;

  return (
    <section id="artisans" className="py-24 lg:py-64 bg-transparent relative overflow-hidden">
      {/* Massive Background Text - Core Identity */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full text-center pointer-events-none opacity-[0.012] select-none">
        <span className="text-[35vw] font-black tracking-tighter text-white leading-none uppercase select-none">FAVOUR</span>
      </div>

      <div className="max-w-[1500px] mx-auto px-6 lg:px-12 relative z-10">
        <div className="mb-24 lg:mb-40 flex flex-col items-center text-center">
          <span className="text-[#D4AF37] font-bold uppercase tracking-[1.5em] text-[10px] lg:text-[12px] mb-8 block animate-pulse">ESTABLISHING_IDENTITY</span>
          <h2 className="text-6xl lg:text-[10rem] font-serif text-white italic tracking-tighter mb-10 leading-none">
            The <span className="not-italic font-bold text-white uppercase">Visionary.</span>
          </h2>
          <div className="w-48 h-[2px] bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent shadow-[0_0_20px_#D4AF37]"></div>
        </div>

        <div className="flex flex-col lg:flex-row items-center gap-20 lg:gap-40 animate-in fade-in slide-in-from-bottom-20 duration-1000 max-w-7xl mx-auto">
          
          {/* Portrait Container - Master Aesthetic */}
          <div className="relative w-full lg:w-1/2 flex justify-center">
            <div className="relative group h-[650px] md:h-[800px] lg:h-[950px] w-full max-w-[650px] rounded-3xl overflow-hidden border border-white/10 shadow-[0_100px_200px_rgba(0,0,0,1)] bg-stone-950 preserve-3d">
              <img 
                src={stylist.imageUrl} 
                alt={stylist.name} 
                className="w-full h-full object-cover transition-all duration-[6s] scale-100 group-hover:scale-110 filter brightness-[0.7] group-hover:brightness-100" 
              />
              
              {/* Artistic Lighting Overlays */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-90 group-hover:opacity-60 transition-opacity duration-1000"></div>
              
              {/* HUD Overlay Elements - Biometric Theme */}
              <div className="absolute top-12 left-12 p-6 glass-hd border-white/10 rounded-2xl backdrop-blur-3xl transition-all duration-1000 group-hover:translate-x-4">
                <p className="text-[#D4AF37] text-[9px] font-black uppercase tracking-[0.5em]">BIOMETRIC_SCAN_ACTIVE</p>
                <div className="flex items-center gap-3 mt-4">
                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_#22c55e]"></div>
                  <p className="text-white text-[12px] font-mono tracking-widest uppercase">Bright_Favour_Verified</p>
                </div>
              </div>

              <div className="absolute bottom-12 right-12 p-6 glass-hd border-white/10 rounded-2xl backdrop-blur-3xl text-right transition-all duration-1000 group-hover:-translate-x-4">
                <p className="text-white/40 text-[8px] font-black uppercase tracking-[0.6em] mb-2">Protocol_Status</p>
                <p className="text-[#D4AF37] text-[10px] font-black uppercase tracking-widest flex items-center justify-end gap-3">
                   Master_Director <span className="w-2 h-2 border border-[#D4AF37] animate-spin-slow"></span>
                </p>
              </div>
            </div>
            
            {/* Ambient Lighting Depth */}
            <div className="absolute -z-10 -bottom-32 -right-32 w-[140%] h-[140%] bg-gradient-to-tr from-[#D4AF37]/20 via-transparent to-transparent blur-[160px] opacity-30"></div>
          </div>

          {/* Biographical Identity - Flagship Hierarchy */}
          <div className="w-full lg:w-1/2 flex flex-col justify-center items-center lg:items-start text-center lg:text-left space-y-16">
            <div className="space-y-6">
              <span className="text-[#D4AF37] text-[15px] font-black uppercase tracking-[1.5em] mb-6 block animate-in slide-in-from-left duration-1000">Master Architect</span>
              <h3 className="text-white font-serif text-6xl md:text-8xl lg:text-9xl italic tracking-tighter leading-[0.8] drop-shadow-2xl">
                {stylist.name}
              </h3>
              <div className="flex flex-wrap justify-center lg:justify-start gap-x-8 gap-y-4 mt-8">
                 {stylist.role.split(' / ').map((r, i) => (
                   <span key={i} className="text-stone-500 text-[11px] font-black uppercase tracking-[0.8em] flex items-center gap-4">
                     {r} {i < stylist.role.split(' / ').length - 1 && <span className="text-[#D4AF37] opacity-20">/</span>}
                   </span>
                 ))}
              </div>
            </div>
            
            <div className="w-full lg:w-3/4 h-[1px] bg-gradient-to-r from-[#D4AF37]/60 to-transparent"></div>
            
            <div className="space-y-12 lg:w-11/12">
              <p className="text-stone-300 text-2xl md:text-3xl lg:text-4xl font-light italic leading-relaxed opacity-90 border-l-4 border-[#D4AF37] pl-12">
                {stylist.bio}
              </p>
              
              <div className="flex flex-wrap justify-center lg:justify-start gap-10">
                <div className="flex items-center gap-4 py-3 px-6 glass-hd rounded-full border-white/5">
                  <div className="w-2 h-2 rounded-full bg-[#D4AF37] shadow-[0_0_10px_#D4AF37]"></div>
                  <span className="text-stone-500 font-mono text-[10px] uppercase tracking-[0.5em]">OSEMENGE_LEGACY</span>
                </div>
                <div className="flex items-center gap-4 py-3 px-6 glass-hd rounded-full border-white/5">
                   <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_10px_#3b82f6]"></div>
                   <span className="text-stone-500 font-mono text-[10px] uppercase tracking-[0.5em]">ABULOMA_CORE_NODE</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center lg:justify-start gap-16 items-center pt-8">
              <a href="#" className="flex items-center gap-8 text-[#D4AF37] hover:text-white transition-all group">
                <div className="p-5 border border-[#D4AF37]/40 rounded-full group-hover:bg-[#D4AF37] group-hover:text-black transition-all duration-700 shadow-2xl scale-110">
                  <InstagramIcon />
                </div>
                <div className="flex flex-col">
                   <span className="text-[11px] font-black uppercase tracking-[0.7em]">Neural_Link</span>
                   <span className="text-stone-600 text-[9px] font-mono mt-2 tracking-widest">@jerroo_favour</span>
                </div>
              </a>
              
              <div className="hidden md:block w-px h-20 bg-gradient-to-b from-transparent via-white/10 to-transparent"></div>
              
              <div className="flex flex-col items-center lg:items-start opacity-50 hover:opacity-100 transition-opacity">
                <span className="text-white text-[12px] font-serif italic tracking-widest">Aesthetic Sovereignty Guaranteed</span>
                <span className="text-stone-800 text-[8px] font-black uppercase tracking-[1em] mt-3">Ready_For_Deployment</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style>{`
        .animate-spin-slow { animation: spin 8s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </section>
  );
};

export default StylistsSection;
