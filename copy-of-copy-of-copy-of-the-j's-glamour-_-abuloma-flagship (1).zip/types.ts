
export interface Service {
  id: string;
  name: string;
  description: string;
  category: 'Hair' | 'Beauty' | 'Grooming';
  price?: string;
  icon: string;
  imageUrl?: string;
}

export interface Stylist {
  id: string;
  name: string;
  role: string;
  bio: string;
  imageUrl: string;
  specialty: 'Hair' | 'Tattoo' | 'Nails' | 'Management';
}

export interface Testimonial {
  id: string;
  author: string;
  text: string;
  rating: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface BookingFormData {
  name: string;
  email: string;
  phone: string;
  service: string;
  stylist: string;
  date: string;
  time: string;
  notes: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}
