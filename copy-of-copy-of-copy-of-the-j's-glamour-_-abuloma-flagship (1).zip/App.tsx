
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ServicesGrid from './components/ServicesGrid';
import AIStylist from './components/AIStylist';
import InfoSection from './components/InfoSection';
import BookingForm from './components/BookingForm';
import PortfolioGallery from './components/PortfolioGallery';
import StylistsSection from './components/StylistsSection';
import ConciergeDashboard from './components/ConciergeDashboard';
import { BUSINESS_INFO } from './constants';
import { API } from './services/api';
import { ContactFormData } from './types';

const NeonMotionBackground: React.FC<{ mouseX: number; mouseY: number }> = ({ mouseX, mouseY }) => {
  return (
    <div className="fixed inset-0 z-[-1] overflow-hidden bg-[#050505] pointer-events-none">
      {/* Dark Neon Gold Pulse */}
      <div 
        className="absolute w-[120vmax] h-[120vmax] rounded-full blur-[150px] opacity-[0.15] mix-blend-screen transition-transform duration-[2000ms] ease-out animate-pulse"
        style={{
          background: 'radial-gradient(circle, rgba(212, 175, 55, 0.4) 0%, transparent 70%)',
          top: '-30%',
          left: '-20%',
          transform: `translate3d(${mouseX * 0.08}px, ${mouseY * 0.08}px, 0)`,
        }}
      />
      
      {/* Pure White Ether */}
      <div 
        className="absolute w-[90vmax] h-[90vmax] rounded-full blur-[120px] opacity-[0.08] mix-blend-overlay transition-transform duration-[3000ms] ease-out"
        style={{
          background: 'radial-gradient(circle, rgba(255, 255, 255, 0.2) 0%, transparent 60%)',
          bottom: '-20%',
          right: '-10%',
          transform: `translate3d(${mouseX * -0.05}px, ${mouseY * -0.05}px, 0)`,
        }}
      />

      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black" />
    </div>
  );
};

const ScrollTopButton: React.FC<{ visible: boolean }> = ({ visible }) => (
  <button 
    onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
    className={`fixed bottom-10 right-10 z-[100] p-5 glass-hd rounded-full border border-[#D4AF37]/30 text-[#D4AF37] transition-all duration-500 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-20 pointer-events-none'}`}
  >
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 10l7-7m0 0l7 7m-7-7v18" /></svg>
  </button>
);

const App: React.FC = () => {
  const [showDashboard, setShowDashboard] = useState(false);
  const [scrollPos, setScrollPos] = useState(0);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [contactForm, setContactForm] = useState<ContactFormData>({ name: '', email: '', subject: '', message: '' });
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrollPos(window.scrollY);
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ 
        x: e.clientX - window.innerWidth / 2, 
        y: e.clientY - window.innerHeight / 2 
      });
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    try {
      await API.processContactMessage(contactForm);
      setSendSuccess(true);
      setContactForm({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setSendSuccess(false), 5000);
    } catch (err) {
      alert("Inquiry transmission failure.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-transparent selection:bg-[#D4AF37] selection:text-black overflow-x-hidden preserve-3d">
      <NeonMotionBackground mouseX={mousePos.x} mouseY={mousePos.y} />
      
      <Navbar />
      
      {showDashboard && <ConciergeDashboard onClose={() => setShowDashboard(false)} />}

      <main className="relative z-10">
        <div className="fixed top-1/2 left-6 -translate-y-1/2 flex flex-col items-center gap-6 z-50 pointer-events-none hidden lg:flex">
           <div className="w-[1px] h-20 bg-gradient-to-b from-transparent to-[#D4AF37]"></div>
           <span className="vertical-text text-[#D4AF37] text-[8px] font-black uppercase tracking-[1em] opacity-40">DEPTH_PROTOCOL</span>
           <div className="w-[1px] h-20 bg-gradient-to-t from-transparent to-[#D4AF37]"></div>
        </div>

        <Hero />
        <ServicesGrid />
        <AIStylist />
        <PortfolioGallery />
        <StylistsSection />
        <InfoSection />
        <BookingForm />
      </main>

      <footer className="pt-32 pb-16 border-t border-white/5 relative bg-black/80 backdrop-blur-xl">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start mb-24">
            <div className="space-y-12">
              <div className="flex items-center gap-6">
                <img src={BUSINESS_INFO.logoUrl} className="w-16 h-16 drop-shadow-[0_0_15px_rgba(212,175,55,0.5)]" alt="Logo" />
                <h3 className="text-3xl font-serif text-white font-bold tracking-widest uppercase italic">THE J'S <span className="text-[#D4AF37]">GLAMOUR</span></h3>
              </div>
              <p className="text-stone-400 text-lg font-light leading-relaxed max-w-md italic">
                Redefining aesthetic standards in Abuloma with geometric precision and refined finishing. Port Harcourt's flagship grooming destination.
              </p>
              
              <div className="space-y-4">
                <p className="text-[#D4AF37] text-[9px] font-black uppercase tracking-[0.6em]">Operational_Node</p>
                <p className="text-white font-mono tracking-widest text-sm">{BUSINESS_INFO.location}</p>
              </div>
            </div>

            <div className="glass-hd p-8 lg:p-12 border border-white/10 rounded-3xl shadow-4xl relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <span className="text-[40px] font-black text-[#D4AF37] tracking-tighter">SECURE_LINK</span>
              </div>
              
              <h4 className="text-2xl font-serif text-white italic mb-8 tracking-tighter">Direct <span className="not-italic font-bold">Inquiry.</span></h4>
              
              {sendSuccess ? (
                <div className="py-12 text-center animate-in fade-in slide-in-from-top-4">
                  <div className="text-green-500 mb-4">
                    <svg className="w-12 h-12 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <p className="text-white text-xs font-black uppercase tracking-[0.5em]">Transmission Successful</p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <input 
                      required
                      type="text" 
                      placeholder="NAME"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                      className="bg-transparent border-b border-white/10 py-3 text-xs font-black uppercase tracking-widest text-white outline-none focus:border-[#D4AF37] transition-all"
                    />
                    <input 
                      required
                      type="email" 
                      placeholder="EMAIL"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                      className="bg-transparent border-b border-white/10 py-3 text-xs font-black uppercase tracking-widest text-white outline-none focus:border-[#D4AF37] transition-all"
                    />
                  </div>
                  <input 
                    required
                    type="text" 
                    placeholder="SUBJECT"
                    value={contactForm.subject}
                    onChange={(e) => setContactForm({...contactForm, subject: e.target.value})}
                    className="w-full bg-transparent border-b border-white/10 py-3 text-xs font-black uppercase tracking-widest text-white outline-none focus:border-[#D4AF37] transition-all"
                  />
                  <textarea 
                    required
                    placeholder="MESSAGE PROTOCOL..."
                    rows={4}
                    value={contactForm.message}
                    onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                    className="w-full bg-transparent border-b border-white/10 py-3 text-xs font-black uppercase tracking-widest text-white outline-none focus:border-[#D4AF37] transition-all resize-none"
                  ></textarea>
                  
                  <button 
                    type="submit"
                    disabled={isSending}
                    className="w-full py-5 bg-white text-black font-black uppercase tracking-[0.8em] text-[10px] hover:bg-[#D4AF37] hover:text-white transition-all disabled:opacity-50 relative overflow-hidden group/btn"
                  >
                    <span className="relative z-10">{isSending ? 'SENDING...' : 'DISPATCH_INQUIRY'}</span>
                    <div className="absolute inset-0 bg-stone-900 translate-y-full group-hover/btn:translate-y-0 transition-transform duration-500"></div>
                  </button>
                </form>
              )}
            </div>
          </div>

          <div className="pt-12 border-t border-white/5 flex flex-col lg:flex-row justify-between items-center gap-12 text-[10px] font-black uppercase tracking-[0.5em] text-stone-600">
             <div className="flex gap-12">
               <span className="hover:text-[#D4AF37] transition-colors cursor-pointer" onClick={() => setShowDashboard(true)}>System_Admin_Access</span>
               <a href="#" className="hover:text-white transition-colors">Legal_Protocols</a>
             </div>
             <span>&copy; 2024 THE J'S GLAMOUR // PHC_NODE_V10.2</span>
          </div>
        </div>
      </footer>

      <ScrollTopButton visible={scrollPos > 500} />

      <style>{`
        .vertical-text { writing-mode: vertical-rl; }
        @keyframes float-slow {
          0%, 100% { transform: translate(0, 0); }
          50% { transform: translate(20px, -20px); }
        }
        .animate-float-slow { animation: float-slow 8s ease-in-out infinite; }
      `}</style>
    </div>
  );
};

export default App;
