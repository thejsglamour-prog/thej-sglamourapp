
import { Service, Stylist } from './types';

export const OFFICIAL_LOGO = `data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTEyIiBoZWlnaHQ9IjUxMiIgdmlld0JveD0iMCAwIDUxMiA1MTIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxkZWZzPgo8bGluZWFyR3JhZGllbnQgaWQ9ImNocm9tZS1ncmFkIiB4MT0iMCIgeTE9IjAiIHgyPSIxIiB5Mj0iMSI+CjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiNGRkZGRkYiIC8+CjxzdG9wIG9mZnNldD0iNDAlIiBzdG9wLWNvbG9yPSIjRDRBRjM3IiAvPgo8c3RvcCBvZmZzZXQ9IjYwJSIgc3RvcC1jb2xvcj0iIzhBNEQyMyIgLz4KPHN0b3Agb2Zmc2V0PSIxMDAlIiBzdG9wLWNvbG9yPSIjMjAyMDIwIiAvPgo8L2xpbmVhckdyYWRpZW50Pgo8ZmlsdGVyIGlkPSJkZWVwLXNoYWRvdyIgeD0iLTIwJSIgeT0iLTIwJSIgd2lkdGg9IjE0MCUiIGhlaWdodD0iMTQwJSI+CjxmZUdhdXNzaWFuQmx1ciBpbj0iU291cmNlQWxwaGEiIHN0ZERldmlhdGlvbj0iOCIgLz4KPGZlT2Zmc2V0IGR4PSIxMCIgZHk9IjEwIiByZXN1bHQ9Im9mZnNldEJsdXIiIC8+CjxmZUNvbXBvc2l0ZSBpbj0iU291cmNlR3JhcGhpYyIgaW4yPSJvZmZzZXRCbHVyIiBvcGVyYXRvcj0ib3ZlciIgLz4KPC9maWx0ZXI+CjwvZGVmcz4KPGcgZmlsdGVyPSJ1cmwoI2RlZXAtc2hhZG93KSI+CjxwYXRoIGQ9Ik0yNTYgNDBDMTM2LjcgNDAgNDAgMTM2LjcgNDAgMjU2UzEzNi43IDQ3MiAyNTYgNDczczExMS44LTQwLjYgMTUyLjUtMTEwLjRsLTQ5LjgtMzAuM0MzMjggMzgyIDI5NC41IDQxMiAyNTYgNDEyYy04Ni4yIDAtMTU2LTE1NnM2OS44LTE1NiAxNTYtMTU2YzQzLjEgIDAgODEuOSA0My4zIDkxLjggMTExLjZsNTcuOCAwQzM5NS42IDEyNS44IDMzMS45IDQwIDI1NiA0MHoiIGZpbGw9InVybCgjY2hyb21lLWdyYWQpIi8+CjxwYXRoIGQ9Ik00MjQuNiAxNTVsLTQzIDc0LjVjMTMuNyA3LjggMjIuMyAyMi4zIDIyLjMgMzguOCAwIDI0LjMtMTkuNyA0NC00NCA0NGgtNTMuNnYtMTQwaDUzLjZjMTUuNCAwIDI5LjUgNi4yIDM5LjggMTYuM2w0NS40LTM3LjVjLTIxLjQtMjEtNTAuOS0zMy44LTgzLjMtMzMuOEgyNDZ2MTkyLjVoMzguOGM0OS43IDAgOTAtNDAuMyA5MC05MHMtMjAuNS04My4yLTUwLTM5Ljd6IiBmaWxsPSJ1cmwoI2Nocm9tZS1ncmFkKSIvPgo8L2c+Cjwvc3ZnPg==`;

export const BUSINESS_INFO = {
  name: "THE J'S GLAMOUR",
  tagline: "Premium Hair & Beauty Salon",
  logoUrl: OFFICIAL_LOGO,
  description: "Port Harcourt's ultimate grooming sanctuary. We fuse technical mastery with elite aesthetics to deliver high-definition beauty transformations in Abuloma.",
  location: "#50 Owudo Street off Bitter Leaf Road, Abuloma, Port Harcourt",
  mapUrl: "https://maps.app.goo.gl/tsMKxSks7THYZZJd8",
  email: "thejsglamour@gmail.com",
  rating: 5.0,
  reviewsCount: 25,
  hours: {
    weekdays: "08:00 – 21:00",
    saturday: "08:00 – 21:00",
    sunday: "12:00 – 21:00"
  },
  phones: ["09011846464", "07048664579"],
  whatsapp: "2349011846464"
};

export const SERVICES: Service[] = [
  { 
    id: '1', 
    name: 'Elite Barbering', 
    description: 'Master-level fades and structural styling with gold-standard precision.', 
    category: 'Hair', 
    price: '₦3,500+', 
    icon: 'scissors',
    imageUrl: 'https://images.unsplash.com/photo-1621605815841-2dddbd274733?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '2', 
    name: 'Geometric Braids', 
    description: 'Complex structural patterns with absolute master-class detailing.', 
    category: 'Hair', 
    price: '₦7,000+', 
    icon: 'brush',
    imageUrl: 'https://images.unsplash.com/photo-1632765854612-9b02b6ec2b15?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '3', 
    name: 'Artistic Ink', 
    description: 'Precision realism and pigment art in a high-fidelity sterile environment.', 
    category: 'Grooming', 
    price: '₦20,000+', 
    icon: 'brush',
    imageUrl: 'https://images.unsplash.com/photo-1590210350293-6a635836853e?auto=format&fit=crop&q=80&w=800'
  },
  { 
    id: '4', 
    name: 'Nail Architecture', 
    description: 'Advanced gel pigments and high-gloss metallic refined finishes.', 
    category: 'Beauty', 
    price: '₦5,000+', 
    icon: 'sparkles',
    imageUrl: 'https://images.unsplash.com/photo-1604654894610-df4906821603?auto=format&fit=crop&q=80&w=800'
  }
];

export const STYLISTS: Stylist[] = [
  {
    id: 'ceo-01',
    name: 'FAVOUR TAMUNO BRIGHT (JERROO)',
    role: 'C.E.O / VISIONARY DIRECTOR / OSEMENGE DESCENDANT',
    bio: 'Jerroo Favour Bright is the visionary lead of THE J\'S GLAMOUR. Often seen at the Abuloma flagship, he embodies the "Urban Elite" aesthetic—mixing high-fashion streetwear with the geometric precision of master barbering. His leadership as an Osemenge descendant brings a unique cultural heritage to the Port Harcourt grooming scene, establishing a new gold standard for refined finishing.',
    specialty: 'Management',
    imageUrl: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?q=80&w=1200&auto=format&fit=crop' 
  }
];

export const PORTFOLIO_ITEMS = [
  { 
    id: 'p1', 
    title: 'Surgical Taper', 
    category: 'Hair', 
    imageUrl: 'https://images.unsplash.com/photo-1592647420248-b74a217f7b17?auto=format&fit=crop&q=80&w=800', 
    isHero: true 
  },
  { 
    id: 'p2', 
    title: 'Refined Gold Nails', 
    category: 'Nails', 
    imageUrl: 'https://images.unsplash.com/photo-1632345031435-8727f6897d53?auto=format&fit=crop&q=80&w=1200', 
    isHero: false 
  },
  { 
    id: 'p3', 
    title: 'Precision Line Ink', 
    category: 'Tattoo', 
    imageUrl: 'https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?auto=format&fit=crop&q=80&w=800', 
    isHero: false 
  }
];
