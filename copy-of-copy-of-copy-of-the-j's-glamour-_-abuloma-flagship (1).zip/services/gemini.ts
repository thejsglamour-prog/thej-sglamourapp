
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

// Note: Vite will replace process.env.API_KEY with the actual value during build
const ai = new GoogleGenAI({ apiKey: (process.env.API_KEY as string) || '' });

const SYSTEM_INSTRUCTION = `
You are the "Master AI Concierge" at THE J'S GLAMOUR, an elite unisex salon flagship in Abuloma, Port Harcourt.
Location: #50 OWUDO STREET OFF BITTER LEAF ROAD ABULOMA, PORT HARCOURT.

PHILOSOPHY:
1. GEOMETRIC PRECISION: Mathematical accuracy in every cut, braid, and stroke.
2. REFINED FINISHING: Absolute master-class detailing that sets the standard in Rivers State.

PRICING PROTOCOLS:
- Elite Barbering: ₦3,500+
- Geometric Braids: ₦7,000+
- Artistic Ink (Tattoo): ₦20,000+
- Nail Architecture: ₦5,000+
- Mani/Pedi: ₦8,000+

Your persona is clinical, sophisticated, and high-end. 
Keep responses concise (under 60 words). 
Always encourage a physical "Geometric Analysis" consultation at the flagship with the Master Director, Jerroo Favour (an Osemenge).
Answer questions specifically about hair styling, beauty treatments, and tattoo artistry within the context of Port Harcourt's elite grooming standards.
`;

export async function* getStyleAdviceStream(history: ChatMessage[]) {
  try {
    const contents = history.map(msg => ({
      role: msg.role,
      parts: [{ text: msg.text }]
    }));

    const response = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.95,
        topK: 40
      },
    });

    for await (const chunk of response) {
      if (chunk.text) {
        yield chunk.text;
      }
    }
  } catch (error) {
    console.error("AI Node Failure:", error);
    yield "Aesthetic calibration interrupted. Please refresh the protocol or contact the flagship node at 09011846464.";
  }
}
